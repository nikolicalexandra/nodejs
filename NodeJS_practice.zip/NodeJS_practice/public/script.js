
       
function showHide6() {
  var x6 = document.getElementById("button-click-6");
  
        if (x6.style.display === "none") {
            x6.style.display = "block";
          } else {
            x6.style.display = "none";
          }
    }

function showHide5() {
  var x5 = document.getElementById("button-click-5");
  
        if (x5.style.display === "none") {
            x5.style.display = "block";
          } else {
            x5.style.display = "none";
          }
    }
function showHide4() {
  var x4 = document.getElementById("button-click-4");
  
        if (x4.style.display === "none") {
            x4.style.display = "block";
          } else {
            x4.style.display = "none";
          }
    }

function showHide3() {
  var x3 = document.getElementById("button-click-3");
  
        if (x3.style.display === "none") {
            x3.style.display = "block";
          } else {
            x3.style.display = "none";
          }
    }
function showHide2() {
  var x2 = document.getElementById("button-click-2");
  
        if (x2.style.display === "none") {
            x2.style.display = "block";
          } else {
            x2.style.display = "none";
          }
    }
function showHide1() {
  var x1 = document.getElementById("button-click-1");
  
        if (x1.style.display === "none") {
            x1.style.display = "block";
          } else {
            x1.style.display = "none";
          }
    }
                         
       
    
    
    
  
