var express = require('express');
var app = express();


app.use(express.static(__dirname + '/public'));


app.get('/', function(req, res){
    res.sendFile(__dirname + '/public/index.html');
});

app.get('/index.html', function(req, res){
    res.sendFile(__dirname + '/public/index.html');
});

app.get('/news.html', function(req, res){
    res.sendFile(__dirname + '/public/news.html');
});

app.get('/cars-for-sale.html', function(req, res){
    res.sendFile(__dirname + '/public/cars-for-sale.html');
});

app.listen(3000);